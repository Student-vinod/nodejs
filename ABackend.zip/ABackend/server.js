const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const axios = require("axios");
const user = require("./routes/userRoutes.js");
let app = express();
app.use(cors());
// mongoose
//   .connect("mongodb://localhost:27017/VinodBackend")
//   .then(() => {
//     console.log("Connected to MongoDB");
//   })
//   .catch((err) => {
//     console.error("Failed to connect to MongoDB", err);
//   });

// app.use(express.urlencoded({ extended: true }));

// app.use(express.json());

// app.use("/api/v2/tickers", user);

app.listen(3000, () => {
  console.log(`Server is running on port ${3000}`);
});


app.get('/api/tickers', async (req, res) => {
  try {
      const response = await axios.get('https://api.wazirx.com/api/v2/tickers');
      const tickers = Object.values(response.data).slice(0, 10);
      console.log(tickers,'tickers')
      res.json(tickers);
  } catch (error) {
      console.error(error);
      res.status(500).send('Error fetching tickers from WazirX.');
  }
});