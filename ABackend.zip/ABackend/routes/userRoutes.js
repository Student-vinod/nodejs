const express = require("express");
const { user, findUser } = require("../controllers/UserController.js");

const router = express.Router();

router.post("/", user);
router.get("/", findUser);

module.exports = router;
