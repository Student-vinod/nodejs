const userModel = require("../model/user.model.js");

const user = async (req, res) => {
  try {
    const {
      base_unit,
      quote_unit,
      low,
      high,
      last,
      type,
      open,
      volume,
      sell,
      buy,
      at,
      name,
    } = req.body;

    if (
      !base_unit ||
      !quote_unit ||
      !low ||
      !high ||
      !last ||
      !type ||
      !open ||
      !volume ||
      !sell ||
      !buy ||
      !at ||
      !name
    ) {
      return res.status(400).json({ message: "Missing required fields" });
    }

    const newUser = new userModel({
      base_unit,
      quote_unit,
      low,
      high,
      last,
      type,
      open,
      volume,
      sell,
      buy,
      at,
      name,
    });

    await newUser.save();
    res
      .status(201)
      .json({ message: "User created successfully", user: newUser });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Internal server error" });
  }
};

const findUser = async (req, res) => {
  try {
    const user = await userModel.find({});
    res.json({
      message: "User found successfully",
      user,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Internal server error" });
  }
};

module.exports = { user, findUser };
